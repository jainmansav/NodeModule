


const express = require('express')
const students = require('./data/ECS')
// const connectDB = require("./db/connect");



var fs = require('fs')
const { escape } = require('querystring')
//const { finished } = require('stream')




const app = express()
// const connectDB = require("./db/connect");
app.use(express.json())
app.listen(3000, () => {
    console.log('listening on port 3000');
})


app.get('/', (req, res) => {
    res.json({ message: "Api is working" })

})

app.get('/api/students', async (req, res) => {
    console.log(123);
    let udata = students;
    await fs.readFile('data/ECS.json',  'utf8', (err,data) => {
        if (err) {
            console.error('Error writing JSON file:', err);
            return;
        }
        console.log("sachin",data)
        res.json(data)
    });
  
        
    //     console.log('JSON file has been saved!');
    //     return res.json({status: true, message: 'JSON file has been saved!'})
    // })

    // res.json(udata)

})


// app.get('/data/ECS', (req, res) => {
//     res.json(ECS)

// })

// app.post('/data/ECS', (req,res) => {
//     const body = req.body;
//     console.log(req.body)

// })




app.post('/api/students', (req, res) => {
    const body = req.body;
    // for(let i=0; i<body.length;i++){

    //     if(!body[i].email){
    //         res.status(400)
    //        return res.status(203).json({err: "email not found", name: body[i]['email']})
    //    }

    console.log(req.body)

//     const user = {
//         id: students.length + 1,
//         first_name: req.body.first_name,
//         last_name: req.body.last_name,
//         email: req.body.email
//     }
//     students.push(user)
//     return res.json(user)



// })
// const jsonData = {
//      ECS: students
//  };

// Convert JSON object to string
// const jsonString = JSON.stringify(jsonData, null, 2);

// Write JSON string to a file
fs.writeFile('data/ECS.json', JSON.stringify(req.body), 'utf8', (err) => {
    if (err) {
        console.error('Error writing JSON file:', err);
        return;
    }

    
    console.log('JSON file has been saved!');
    return res.json({status: true, message: 'JSON file has been saved!'})
})


// const ECS = fs.readFileSync('ECS.json', 'utf8');
                

// // Update the desired property in the JSON object
// jsonData.propertyToUpdate = 'New Value';

// // Convert the updated JSON object back to a string      
// const updatedData = JSON.stringify(jsonData, null, 2);

// // Write the updated data back to the JSON file
// fs.writeFileSync('ECS.json', updatedData, 'utf8');

// console.log('Data updated successfully.');




})


