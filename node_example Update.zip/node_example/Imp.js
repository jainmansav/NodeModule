// const MongoClient = require('mongodb').MongoClient;
// const fs = require('fs');
// const data = require('./data/ECS.json')


// const url = 'mongodb+srv://jainmansav01:VHEwciwuGrkBfbtf@cluster0.2etsdqf.mongodb.net/';
// const dbName = 'FinalStudent';


// const jsonData = JSON.parse(fs.readFileSync('C:/Users/Hp/node_example/data/ECS.json', 'utf8'));


// app.get('/api/data/ECS', async (req, res) => {
//   try {
//       const collection = client.db('FinalStudent').collection('Std');
//       const data = await collection.find({}).toArray();
//       res.json(data);
//   } catch (error) {
//       console.error('Error fetching data:', error);
//       res.status(500).json({ error: 'Internal server error' });
//   }
// });

// app.post('/api/data/ECS', async (req, res) => {
//   try {
//       const collection = client.db('FinalStudent').collection('Std');
//       const data = req.body;
//       const result = await collection.insertOne(data);
//       res.json(result);
//   } catch (error) {
//       console.error('Error inserting data:', error);
//       res.status(500).json({ error: 'Internal server error' });
//   }
// });

    

// insertDataIntoMongoDB(jsonData);
