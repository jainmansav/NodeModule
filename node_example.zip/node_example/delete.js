const MongoClient = require('mongodb').MongoClient;
const fs = require('fs');
const data = require('./data/ECS.json')

// Connection URL and database name
const url = 'mongodb+srv://jainmansav01:tlG80kYoVv1t6L8y@cluster18.6wbiv6r.mongodb.net/';
const dbName = 'ManasavData';

// Read the JSON file
const jsonData = JSON.parse(fs.readFileSync('C:/Users/Hp/node_example/data/ECS.json', 'utf8'));

// Function to insert JSON data into MongoDB
async function insertDataIntoMongoDB() {
  try {
    // Connect to the MongoDB server
    const client = await MongoClient.connect(url);
    console.log('Connected successfully to server');

    // Select the database
    const db = client.db(dbName);

    // Select the collection
    const collection = db.collection('SchoolD');

    // deleted the JSON data into the collection
    const result = await collection.deleteMany(data);
    console.log(data)
    console.log(`${result.insertedCount} documents inserted`);

    // const updated = await collection.updateMany(data);
    // console.log(data)
    // console.log(`${updated.insertedCount} documents updated`)

    // Close the connection
    client.close();
    console.log('Connection closed');
  } catch (err) {
    console.log('Error:', err);
  }
}

// Call the function to insert data
insertDataIntoMongoDB(jsonData);
