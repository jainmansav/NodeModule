const express = require('express');
const app = express();
const port = 3000;
const fs = require('fs');
// Middleware to parse JSON request bodies
app.use(express.json());

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

const { MongoClient } = require('mongodb');

const uri = 'mongodb+srv://jainmansav01:VHEwciwuGrkBfbtf@cluster0.2etsdqf.mongodb.net/';
const client = new MongoClient(uri);

async function connectToMongo() {
  try {
    await client.connect();
    console.log('Connected to MongoDB');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
  }
}

connectToMongo();

app.get('/api/data', async (req, res) => {
    try {
      const collection = client.db('FinalStudent').collection('Std');
      const data = await collection.find({}).toArray();
      res.json(data);
    } catch (error) {
      console.error('Error fetching data:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  app.post('/api/data', async (req, res) => {
    try {
      const collection = client.db('FinalStudent').collection('Std');
  
      
      const jsonData = fs.readFileSync('C:/Users/Hp/node_example/data/ECS.json', 'utf-8');
      const parsedData = JSON.parse(jsonData);
  
      const result = await collection.insertMany(parsedData);
      res.json(result);
    } catch (error) {
      console.error('Error saving data:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
  